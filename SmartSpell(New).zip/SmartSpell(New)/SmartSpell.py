import customtkinter as ctk
import language_tool_python
import threading
import json
import os

class SmartSpellApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SmartSpell - AI Grammar Checker")
        self.root.geometry("1000x700")
        self.root.resizable(True, True)
        
        # Set the theme
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        
        # Initialize Language Tool
        self.language_tool = None
        self.language_tool_initialized = False
        self.initialize_language_tool_thread()
        
        # History file
        self.history_file = "smartspell_history.json"
        self.history = []
        self.load_history()
        
        # Create main frame
        self.main_frame = ctk.CTkFrame(self.root, corner_radius=10)
        self.main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Create heading
        self.heading_label = ctk.CTkLabel(
            self.main_frame, 
            text="SmartSpell", 
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color="#4e8cff"
        )
        self.heading_label.pack(pady=(0, 10))
        
        # Create content frame
        self.content_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.content_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create left frame (input)
        self.left_frame = ctk.CTkFrame(self.content_frame, corner_radius=8)
        self.left_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))
        
        # Input label
        self.input_label = ctk.CTkLabel(
            self.left_frame, 
            text="Your Text:", 
            font=ctk.CTkFont(size=16, weight="bold")
        )
        self.input_label.pack(anchor="w", padx=10, pady=(10, 5))
        
        # Input text area
        self.input_text = ctk.CTkTextbox(
            self.left_frame, 
            font=ctk.CTkFont(size=14),
            wrap="word",
            corner_radius=6,
            border_width=1,
            border_color="#333333",
            fg_color="#1a1a1a"
        )
        self.input_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        # Button frame
        self.button_frame = ctk.CTkFrame(self.left_frame, fg_color="transparent")
        self.button_frame.pack(fill="x", padx=10, pady=(0, 10))
        
        # Clear button
        self.clear_button = ctk.CTkButton(
            self.button_frame, 
            text="Clear",
            font=ctk.CTkFont(size=14),
            command=self.clear_text,
            height=40,
            fg_color="#333333",
            hover_color="#444444"
        )
        self.clear_button.pack(side="left", fill="x", expand=True, padx=(0, 5))
        
        # Check button
        self.check_button = ctk.CTkButton(
            self.button_frame, 
            text="Check Grammar", 
            font=ctk.CTkFont(size=14, weight="bold"),
            command=self.check_grammar,
            height=40,
            fg_color="#4e8cff",
            hover_color="#3a7cff"
        )
        self.check_button.pack(side="right", fill="x", expand=True, padx=(5, 0))
        
        # Create right frame (output)
        self.right_frame = ctk.CTkFrame(self.content_frame, corner_radius=8)
        self.right_frame.pack(side="right", fill="both", expand=True)
        
        # Output label
        self.output_label = ctk.CTkLabel(
            self.right_frame, 
            text="Corrections", 
            font=ctk.CTkFont(size=16, weight="bold")
        )
        self.output_label.pack(anchor="w", padx=10, pady=(10, 5))
        
        # Output text area
        self.output_text = ctk.CTkTextbox(
            self.right_frame, 
            font=ctk.CTkFont(size=14),
            wrap="word",
            corner_radius=6,
            border_width=1,
            border_color="#333333",
            fg_color="#1a1a1a"
        )
        self.output_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        # Create history frame
        self.history_frame = ctk.CTkFrame(self.main_frame, height=100, corner_radius=8)
        self.history_frame.pack(fill="x", padx=10, pady=(0, 10))
        
        # History label
        self.history_label = ctk.CTkLabel(
            self.history_frame, 
            text="Recent Checks", 
            font=ctk.CTkFont(size=14, weight="bold")
        )
        self.history_label.pack(anchor="w", padx=10, pady=(10, 5))
        
        # History text area
        self.history_text = ctk.CTkTextbox(
            self.history_frame, 
            font=ctk.CTkFont(size=12),
            wrap="word",
            height=60,
            corner_radius=6,
            border_width=1,
            border_color="#333333",
            fg_color="#1a1a1a"
        )
        self.history_text.pack(fill="x", padx=10, pady=(0, 10))
        self.history_text.configure(state="disabled")
        
        # Status label
        self.status_label = ctk.CTkLabel(
            self.main_frame, 
            text="Initializing SmartSpell engine...", 
            font=ctk.CTkFont(size=12),
            text_color="yellow"
        )
        self.status_label.pack(pady=(0, 10))

    def load_history(self):
        """Load history from file if it exists"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    self.history = json.load(f)
            except:
                self.history = []
    
    def save_history(self):
        """Save history to file"""
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.history, f)
        except:
            pass
    
    def update_history(self, text):
        """Update the history with new text"""
        if not text.strip():
            return
            
        # Limit history to 5 items
        if len(self.history) >= 5:
            self.history.pop(0)
            
        self.history.append(text[:100] + "..." if len(text) > 100 else text)
        self.save_history()
        self.display_history()
    
    def display_history(self):
        """Display the history in the history text area"""
        self.history_text.configure(state="normal")
        self.history_text.delete("1.0", "end")
        
        if not self.history:
            self.history_text.insert("1.0", "No recent checks yet.")
        else:
            for i, text in enumerate(reversed(self.history), 1):
                self.history_text.insert("end", f"{i}. {text}\n")
        
        self.history_text.configure(state="disabled")
    
    def clear_text(self):
        """Clear the input text area"""
        self.input_text.delete("1.0", "end")
        self.output_text.delete("1.0", "end")
        self.status_label.configure(text="Ready", text_color="green")

    def initialize_language_tool_thread(self):
        """Initialize the language tool in a separate thread to avoid UI freezing"""
        def initialize():
            try:
                self.language_tool = language_tool_python.LanguageTool('en-US')
                self.language_tool_initialized = True
                self.root.after(0, lambda: self.status_label.configure(
                    text="SmartSpell engine ready", text_color="green"))
            except Exception as e:
                self.root.after(0, lambda: self.status_label.configure(
                    text=f"Error initializing engine: {str(e)}", text_color="red"))
        
        thread = threading.Thread(target=initialize)
        thread.daemon = True
        thread.start()
        
    def check_grammar(self):
        """Check the grammar and spelling of the input text"""
        if not self.language_tool_initialized:
            self.output_text.delete("1.0", "end")
            self.output_text.insert("1.0", "SmartSpell engine is still initializing. Please wait...")
            return
            
        # Get input text
        input_text = self.input_text.get("1.0", "end-1c").strip()
        
        if not input_text:
            self.output_text.delete("1.0", "end")
            self.output_text.insert("1.0", "Please enter some text to check.")
            return
            
        # Update history
        self.update_history(input_text)
            
        # Show processing status
        self.status_label.configure(text="Processing...", text_color="yellow")
        self.output_text.delete("1.0", "end")
        
        # Process in a separate thread to keep UI responsive
        def process_text():
            try:
                matches = self.language_tool.check(input_text)
                
                if not matches:
                    self.root.after(0, lambda: self.output_text.insert("1.0", "No corrections needed. Your text looks perfect!"))
                    self.root.after(0, lambda: self.status_label.configure(
                        text="Analysis complete", text_color="green"))
                    return
                
                # Intelligently apply corrections with context awareness
                corrected_text = input_text
                
                # Sort matches by their position to process them in order
                sorted_matches = sorted(matches, key=lambda m: m.offset)
                offset_adjustment = 0  # To track text position changes after corrections
                
                # Store corrections to show in detail section
                corrections = []
                
                for match in sorted_matches:
                    # Skip corrections for likely proper nouns (capitalized words not at start of sentence)
                    is_likely_proper_noun = False
                    if match.context and len(match.context) > 4:
                        error_word = match.context[match.offsetInContext:match.offsetInContext+match.errorLength]
                        # Check if word is capitalized and not at start of sentence
                        if (error_word and error_word[0].isupper() and 
                            match.offsetInContext > 0 and match.context[match.offsetInContext-1] != '.'):
                            # Allow punctuation and capitalization corrections even for proper nouns
                            if not any(p in match.message.lower() for p in ["punctuation", "comma", "period", "apostrophe", 
                                                                          "quotation", "hyphen", "dash", "colon", "semicolon", 
                                                                          "capital letter"]):
                                # This is likely a name or proper noun - don't auto-correct
                                is_likely_proper_noun = True
                    
                    # Extract error position in the current corrected text
                    start_pos = match.offset + offset_adjustment
                    end_pos = start_pos + match.errorLength
                    
                    # Choose the most appropriate replacement
                    replacement = ""
                    if match.replacements:
                        # Handle punctuation errors with high priority
                        if any(p in match.message.lower() for p in ["punctuation", "comma", "period", "apostrophe", "quotation", "hyphen", "dash", "colon", "semicolon"]):
                            replacement = match.replacements[0]  # Usually the first suggestion for punctuation is correct
                        # For capitalization errors
                        elif "capital letter" in match.message.lower():
                            replacement = match.replacements[0]  # Usually straightforward
                        # For spelling errors, use more intelligent selection
                        elif "Possible spelling mistake" in match.message:
                            # Extract the error word
                            error_word = corrected_text[start_pos:end_pos].lower()
                            
                            # First, try to find common greeting words as they're frequently used
                            greeting_words = ["hello", "hi", "hey", "good"]
                            for suggestion in match.replacements:
                                if suggestion.lower() in greeting_words:
                                    replacement = suggestion
                                    break
                            
                            # If no greeting word found, use Levenshtein distance to find closest match
                            if not replacement:
                                # Simple function to calculate Levenshtein distance
                                def levenshtein(s1, s2):
                                    if len(s1) < len(s2):
                                        return levenshtein(s2, s1)
                                    if len(s2) == 0:
                                        return len(s1)
                                    previous_row = range(len(s2) + 1)
                                    for i, c1 in enumerate(s1):
                                        current_row = [i + 1]
                                        for j, c2 in enumerate(s2):
                                            insertions = previous_row[j + 1] + 1
                                            deletions = current_row[j] + 1
                                            substitutions = previous_row[j] + (c1 != c2)
                                            current_row.append(min(insertions, deletions, substitutions))
                                        previous_row = current_row
                                    return previous_row[-1]
                                
                                # Find the closest match based on Levenshtein distance
                                best_distance = float('inf')
                                for suggestion in match.replacements:
                                    distance = levenshtein(error_word, suggestion.lower())
                                    # Also consider if first letter matches (important for proper matching)
                                    first_letter_bonus = 0 if error_word and suggestion and error_word[0] == suggestion[0].lower() else 2
                                    adjusted_distance = distance + first_letter_bonus
                                    
                                    if adjusted_distance < best_distance:
                                        best_distance = adjusted_distance
                                        replacement = suggestion
                        # For other errors, choose based on context
                        else:
                            replacement = match.replacements[0]
                    
                    # Add to corrections list
                    correction = f"• Error: \"{match.context}\" \n"
                    correction += f"  Issue: {match.message} \n"
                    if match.replacements:
                        correction += f"  Suggestion: {', '.join(match.replacements[:3])} \n"
                    corrections.append(correction)
                    
                    # Apply the correction if it seems appropriate
                    if replacement and not is_likely_proper_noun:
                        # Apply correction
                        corrected_text = corrected_text[:start_pos] + replacement + corrected_text[end_pos:]
                        # Update offset for future corrections
                        offset_adjustment += len(replacement) - match.errorLength
                
                output = "✅ Corrected text:\n\n" + corrected_text + "\n\n"
                output += "📝 Details:\n\n" + "\n".join(corrections)
                
                self.root.after(0, lambda: self.output_text.delete("1.0", "end"))
                self.root.after(0, lambda: self.output_text.insert("1.0", output))
                self.root.after(0, lambda: self.status_label.configure(
                    text="Analysis complete", text_color="green"))
                
            except Exception as e:
                self.root.after(0, lambda: self.output_text.delete("1.0", "end"))
                self.root.after(0, lambda: self.output_text.insert("1.0", f"Error: {str(e)}"))
                self.root.after(0, lambda: self.status_label.configure(
                    text="Error occurred", text_color="red"))
        
        thread = threading.Thread(target=process_text)
        thread.daemon = True
        thread.start()


if __name__ == "__main__":
    root = ctk.CTk()
    app = SmartSpellApp(root)
    root.mainloop()